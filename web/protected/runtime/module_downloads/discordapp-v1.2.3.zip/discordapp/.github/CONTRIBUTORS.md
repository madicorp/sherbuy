# Contrubutors

### Core Code
[@GreenMeteor](https://github.com/GreenMeteor)

[@Felli](https://github.com/felli)

[@WebCrew](https://github.com/webcrew)

[@humhub](https://github.com/humhub)

### Language/Translations
- English ([@GreenMeteor](https://github.com/GreenMeteor))
- Japanese ([@Felli](https://github.com/felli))
- Chinese ([@Felli](https://github.com/felli))
- Spanish ([@cavp28](https://github.com/cavp28))
- German ([@Felli](https://github.com/felli))
- Portuguese ([@caiqueff](https://github.com/caiqueff))
- Russian ([@buslov](https://github.com/buslov))
- Korean ([@Felli](https://github.com/felli))
- French ([@Felli](https://github.com/felli))
