
### What steps will reproduce the problem?

### What is the expected result?

### What do you get instead?


### Additional info

| Q                | A
| ---------------- | ---
| HumHub version   | 1.?
| PHP version      | 
| Operating system |

> Note: Also provide the full error stacks from `ACP --> Information --> Logging` and errors from your browser console.
