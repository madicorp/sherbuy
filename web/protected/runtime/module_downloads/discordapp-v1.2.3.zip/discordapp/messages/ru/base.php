<?php
    return [
        '<strong>Discord</strong> Chat' => 'Чат <strong>Discord</strong>',
        'Discord Settings' => 'Настройки Discord',
        'Discord Widget URL:' => 'URL-адрес виджета Discord:',
        '<strong>Discord</strong> module configuration' => 'Конфигурация модуля <strong>Discord</strong>',
        'Save' => 'Сохранить',
    ];
