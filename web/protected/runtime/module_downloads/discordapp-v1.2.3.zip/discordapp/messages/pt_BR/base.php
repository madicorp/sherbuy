<?php
    return [
        '<strong>Discord</strong> Chat' => '<strong>Discord</strong> Chat',
        'Discord Settings' => 'Configurações do Discord',
        'Discord Widget URL:' => 'URL do Widget Discord:',
        '<strong>Discord</strong> module configuration' => 'Configuração do módulo do <strong>Discord</strong>',
        'Save' => 'Salvar',
    ];
