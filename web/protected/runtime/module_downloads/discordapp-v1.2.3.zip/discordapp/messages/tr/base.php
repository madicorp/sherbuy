<?php
return [
    '<strong>Discord</strong> Chat' => '<strong>Discord</strong> Sohbet',
    'Discord Settings' => 'Discord Ayarlar',
    'Discord Widget URL:' => 'Discord Widget URL:',
    '<strong>Discord</strong> module configuration' => '<strong>Discord</strong> modül yapılandırması',
    'Save' => 'Kaydet',
];
