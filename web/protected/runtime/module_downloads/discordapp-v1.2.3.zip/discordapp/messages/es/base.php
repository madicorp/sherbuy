<?php
    return [
        '<strong>Discord</strong> Chat' => '<strong>Discord</strong> Chat',
        'Discord Settings' => 'Ajustes de Discord',
        'Discord Widget URL:' => 'URL del Widget Discord',
        '<strong>Discord</strong> module configuration' => 'Configuración del módulo <strong>Discord</strong>',
        'Save' => 'Guardar',
    ];
