<?php
    return [
        '<strong>Discord</strong> Chat' => '<strong>Discord</strong> 채팅',
        'Discord Settings' => 'Discord 설정을',
        'Discord Widget URL:' => 'Discord 위젯 URL:',
        '<strong>Discord</strong> module configuration' => '<strong>Discord</strong> 모듈 구성',
        'Save' => '저장',
    ];
