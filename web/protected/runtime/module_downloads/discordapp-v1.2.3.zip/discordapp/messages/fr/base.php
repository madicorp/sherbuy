<?php
    return [
        '<strong>Discord</strong> Chat' => '<strong>Discord</strong> Chat',
        'Discord Settings' => 'Discord Paramètres',
        'Discord Widget URL:' => 'Discord Widget URL:',
        '<strong>Discord</strong> module configuration' => '<strong>Discord</strong> configuration du module',
        'Save' => 'Sauver',
    ];
