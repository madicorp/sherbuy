<?php
    return [
        '<strong>Discord</strong> Chat' => '<strong>Discord</ strong>聊天',
        'Discord Settings' => 'Discord 建立',
        'Discord Widget URL:' => 'Discord 窗口小部件 URL:',
        '<strong>Discord</strong> module configuration' => '<strong>Discord</strong> 模塊配置',
        'Save' => '保存',
    ];
